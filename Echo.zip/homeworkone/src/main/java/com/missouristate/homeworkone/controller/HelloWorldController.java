package com.missouristate.homeworkone.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

// Keegan Spell
@Controller
public class HelloWorldController {

    @GetMapping("/")
    public String getIndex() {
        return "helloworld";
    }
}
